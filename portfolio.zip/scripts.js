document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Form submitted! Thank you for your message.');
    // Here you can add functionality to send the form data to your email or server
});
